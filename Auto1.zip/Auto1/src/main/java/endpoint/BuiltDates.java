package endpoint;

import sourceURL.source;

public class BuiltDates extends source{
	public static String resource="/v1/car-types/built-dates";	
}
