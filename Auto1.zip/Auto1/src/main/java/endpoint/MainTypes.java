package endpoint;

import sourceURL.source;

public class MainTypes extends source {
	public static String resource="/v1/car-types/main-types";	
}
