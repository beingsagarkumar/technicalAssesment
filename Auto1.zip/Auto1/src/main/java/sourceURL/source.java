package sourceURL;

import static io.restassured.RestAssured.get;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;

import endpoint.MainTypes;
import endpoint.Manufacturer;

public class source {
	public static String baseURL="<Enter Base URL here>";
	public static String wa_key="<Enter Key Here>";
	public static String locale="",manufacturer="",mainType="";
	public static String resource,responseBody,uri;
	public static int statusCode;
	public static Map<String,String>  ResponseBodyMap,responseTextMap;
	public static XSSFWorkbook workbook;
	public static XSSFSheet sheet;
	public static Row row;
	public static Cell cell, key, value;
	
	// Setting up resource with base URL along with wa_key
		public static String setResource(String resource) {
			uri=(baseURL+resource+"?wa_key="+wa_key);
			System.out.println("Resource: " + uri);
			return uri;
		}
	
	// Manufacturer resource with base URL along with wa_key and locale
		public static String setResource(String resource, String localeParam) {
			uri=(baseURL + resource + "?locale=" +localeParam + "&wa_key=" + wa_key);
			System.out.println("\nResource: " + uri);
			return uri;
		}
		
	// Main Types resource with base URL along with wa_key, locale and manufacturer
		public static String setResource(String resource, String localeParam, String manufacturerParam) {
			uri=(baseURL + resource +"?locale=" +localeParam +"&manufacturer="+ manufacturerParam + "&wa_key=" + wa_key );
			System.out.println("\nResource: " + uri);
			return uri;
		}
	
	// Built types resource with base URL along with wa_key, locale, manufacturer and main type
		public static String setResource(String resource, String localeParam, String manufacturerParam, String mainTypeParamValue) {
			uri=(baseURL + resource + "?locale=" +localeParam +"&manufacturer="+ manufacturerParam + 
					"&main-type=" + mainTypeParamValue+ "&wa_key=" + wa_key );
			System.out.println("\nResource: " + uri);
			return uri;
		}
	
	//Fetching request response code
		public static int getResponseCode(String resource) throws IOException {
			statusCode=get(resource).getStatusCode();
			if(statusCode != 200)
				throw new RuntimeException("HttpResponseCode: " +statusCode);	
			return statusCode;
		}

	//Fetching request response body in map format
		public static Map<String,String> getResponseText(String resource) {
			ResponseBodyMap=get(resource).jsonPath().getMap("wkda");
			System.out.println("Response Body: " + ResponseBodyMap);
			return ResponseBodyMap;
			}

	//To Compare GET method response body, fetching expected response from external predefined excel file
		public static Map<String,String> getExternalResponseText(String fileName) throws IOException {
			Map<String, String> mapExternal= new HashMap<String,String>();
			DecimalFormat formatting= new DecimalFormat("000");
			try {
				workbook = new XSSFWorkbook(new FileInputStream("src/test/resources/ResponseBodyValidationFiles/"+ fileName+ ".xlsx")); 
		        sheet = workbook.getSheetAt(0);
		        int j=0;
		        // Different formatting options for respective cell type
		        if(sheet.getRow(0).getCell(0).getCellTypeEnum().toString().contains("NUMERIC") &&
		        		sheet.getRow(0).getCell(1).getCellTypeEnum().toString().contains("STRING")){
			        while(j<=sheet.getLastRowNum()) {
				        key= sheet.getRow(j).getCell(0); 
				        value= sheet.getRow(j).getCell(1);
				        
				        mapExternal.put(String.valueOf(formatting.format(key.getNumericCellValue())), 
				        		value.getStringCellValue());
				        j++;
			        }
		        }
		        else {
		        	if(sheet.getRow(0).getCell(0).getCellTypeEnum().toString().contains("STRING") &&
			        		sheet.getRow(0).getCell(1).getCellTypeEnum().toString().contains("STRING")) {
			        	while(j<=sheet.getLastRowNum()) {
					        key= sheet.getRow(j).getCell(0); 
					        value= sheet.getRow(j).getCell(1);
					        				        
					        mapExternal.put(key.getStringCellValue(),value.getStringCellValue());
					        j++;
					        }
				         }
		        	else {	
		        		
		        		 if(sheet.getRow(0).getCell(0).getCellTypeEnum().toString().contains("NUMERIC") &&
					        		sheet.getRow(0).getCell(1).getCellTypeEnum().toString().contains("NUMERIC")) {
		        			 formatting= new DecimalFormat("0000");
		        			 while(j<=sheet.getLastRowNum()) {
							        key= sheet.getRow(j).getCell(0); 
							        value= sheet.getRow(j).getCell(1);
							        				        
							        mapExternal.put(String.valueOf(formatting.format(key.getNumericCellValue())),
							        		String.valueOf(formatting.format(value.getNumericCellValue())));
							        j++;
							        }
				        	 }
				        		
				        }
				      }
			}
			catch(Exception ex) {
				ex.printStackTrace();
			}
			finally {
				workbook.close();
			}
				System.out.println("External Map: " + mapExternal);
				return mapExternal;
		}

	//Fetching response body for all manufacturer on Maintypes endpoint
		public static void parametrizingMainTypesForAllManufacturer() throws IOException {
		resource=setResource(Manufacturer.resource);
		Set<String> keys=getResponseText(resource).keySet();
		workbook = new XSSFWorkbook(); 
	    sheet = workbook.createSheet("MainTypes_Reponse_For_All_Manufacturer");
	    int rowNum=1;
		for(String manufacturerValue: keys) {
			try {
				row = sheet.createRow(rowNum++); 
				System.out.print("\n\nManufacturer code: " + manufacturerValue);
				resource=source.setResource(MainTypes.resource,"",manufacturerValue);
				responseTextMap=getResponseText(resource);
				cell = row.createCell(0); 
				cell.setCellValue(manufacturerValue);
				cell = row.createCell(1); 
				cell.setCellValue(responseTextMap.toString());
				Assert.assertTrue(!responseTextMap.isEmpty());
			}
			catch(AssertionError ex) {
				cell = row.createCell(0); 
				cell.setCellValue(manufacturerValue);
				cell = row.createCell(1); 
				cell.setCellValue("Fail");
				System.out.println("Failing for manufacturer: "+ manufacturerValue );
			}
			catch(Exception e) {}
		}
		FileOutputStream out = new FileOutputStream(new File
				("src/test/resources/ReponseOutputFiles/MainTypeseResponseForAllmanufacturer.xlsx")); 
	    workbook.write(out); 
	    out.close(); 
		}



}
