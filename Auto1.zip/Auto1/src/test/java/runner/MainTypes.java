package runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/test/java/feature",
		glue= {"gluecode"},
		format= {"pretty",
				"html:target/cucumber/cucumber-pretty",
				"json:target/cucumber.json"},
		tags= {"~@MainTypes"},
		  monochrome = true
		
		)

public class MainTypes extends AbstractTestNGCucumberTests {

}
