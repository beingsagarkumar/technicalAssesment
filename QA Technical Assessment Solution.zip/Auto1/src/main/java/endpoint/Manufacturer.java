package endpoint;

import sourceURL.source;

public class Manufacturer extends source {
	
	public static String resource="/v1/car-types/manufacturer";	

}
