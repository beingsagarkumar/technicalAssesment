package gluecode;

import java.util.Map;
import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import endpoint.BuiltDates;
import endpoint.MainTypes;
import endpoint.Manufacturer;
import sourceURL.source;

public class TestStep {

String resource,responseText;
int statusCode;
Boolean outputFlag;
Map<String,String> responseTextMap, ExternalResponseTextMap;

@Given("^Validate manufacturer endpoint with \"([^\"]*)\"$")
public void validate_manufacturer_endpoint_with(String localeParamValue) throws Throwable {
	resource=source.setResource(Manufacturer.resource, localeParamValue);
	Assert.assertNotNull("Endpoint is avaliable", resource);  
}

@Given("^Validate MainTypes endpoint with \"([^\"]*)\" and \"([^\"]*)\"$")
public void validate_MainTypes_endpoint_with_and(String localeParamValue, String manufacturerParamValue) throws Throwable {
	resource=source.setResource(MainTypes.resource, localeParamValue, manufacturerParamValue);
	Assert.assertNotNull("Endpoint is avaliable", resource);  
}

@Given("^Validate BuiltDates endpoint with \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
public void validate_BuiltDates_endpoint_with_and(String localeParamValue, String manufacturerParamValue, 
		String mainTypeParamValue) throws Throwable {
	resource=source.setResource(BuiltDates.resource, localeParamValue, manufacturerParamValue,mainTypeParamValue );
	Assert.assertNotNull("Endpoint is avaliable", resource);  
}

@Given("^Validate MainTypes endpoint for all Manufacturer$")
public void validate_MainTypes_endpoint_for_all_Manufacturer() throws Throwable {
    System.out.println("Validating response for all manufacturers with main-types endpoint");
}

@When("^Validate GET request is submitted$")
public void validate_GET_request_is_submitted() throws Throwable {
	try {
		statusCode=source.getResponseCode(resource);;
		}
	catch(Exception ex) {
		System.out.println("Get Request is not successful");
		}
	Assert.assertNotNull("GET method is executed successfully",statusCode);
}

@Then("^Validate (\\d+) success status code for manufacturer$")
public void validate_success_status_code_for_manufacturer(int expectedStatusCode) throws Throwable {
	Assert.assertEquals(expectedStatusCode, statusCode); 
}

@Then("^Validate \"([^\"]*)\" response for manufacturer$")
public void validate_response_for_manufacturer(Boolean statusFlag) throws Throwable {
	try {
		responseTextMap=source.getResponseText(resource);
		outputFlag = !responseTextMap.isEmpty();
		}
	catch(Exception ex) {
			outputFlag=false;
		}
	Assert.assertEquals(statusFlag,outputFlag);
}

@Then("^Validate (\\d+) success status code for MainTypes$")
public void validate_success_status_code_for_MainTypes(int expectedStatusCode) throws Throwable {
	Assert.assertEquals(expectedStatusCode, statusCode); 
    
}

@Then("^Validate \"([^\"]*)\" response for MainTypes$")
public void validate_response_for_MainTypes(Boolean statusFlag) throws Throwable {
	try {
		responseTextMap=source.getResponseText(resource);
		outputFlag = !responseTextMap.isEmpty();
		}
	catch(Exception ex) {
			outputFlag=false;
		}
	Assert.assertEquals(statusFlag, outputFlag);
   	}

@Then("^Validate (\\d+) success status code for BuiltDates$")
public void validate_success_status_code_for_BuiltDates(int expectedStatusCode) throws Throwable {
	Assert.assertEquals(expectedStatusCode, statusCode);
}

@Then("^Validate \"([^\"]*)\" response for BuiltDates$")
public void validate_response_for_BuiltDates(Boolean statusFlag) throws Throwable {
	try {
		responseTextMap=source.getResponseText(resource);
		outputFlag = !responseTextMap.isEmpty();
		}
	catch(Exception ex) {
			outputFlag=false;
		}
	Assert.assertEquals(statusFlag, outputFlag);
   	}

@Then("^Validate Response body content for Manufacturer$")
public void validate_Response_body_content_for_Manufacturer() throws Throwable {
	try {
		responseTextMap=source.getResponseText(resource);
		
		//pass excel file name in method getExternalResponseText
		ExternalResponseTextMap = source.getExternalResponseText("Manufacturer");
		}
	catch(Exception ex) {
			outputFlag=false;
		}
	System.out.println("Sizes: " + ExternalResponseTextMap.size() +" ...  "+ responseTextMap.size());
	Assert.assertEquals(ExternalResponseTextMap.size(),responseTextMap.size());
	Assert.assertTrue(ExternalResponseTextMap.equals(responseTextMap));
   	}
    
@Then("^Validate Response body content for MainTypes with \"([^\"]*)\"$")
public void validate_Response_body_content_for_MainTypes_with(String manufacturerParamValue) throws Throwable {
	try {
		responseTextMap=source.getResponseText(resource);
		
		//pass excel file name in method getExternalResponseText
		ExternalResponseTextMap = source.getExternalResponseText("Manufacturer_"+manufacturerParamValue);
		}
	catch(Exception ex) {
			outputFlag=false;
		}
	System.out.println("Sizes: " + ExternalResponseTextMap.size() +" ...  "+ responseTextMap.size());
	Assert.assertEquals(ExternalResponseTextMap.size(),responseTextMap.size());
	Assert.assertTrue(ExternalResponseTextMap.equals(responseTextMap));
	}

@Then("^Validate Response body content for BuiltDates with \"([^\"]*)\" and \"([^\"]*)\"$")
public void validate_Response_body_content_for_BuiltDates_with_and(String manufacturerParamValue, 
		String mainTypeParamValue) throws Throwable {
	try {
		responseTextMap=source.getResponseText(resource);
		
		//pass excel file name in method getExternalResponseText
		ExternalResponseTextMap = source.getExternalResponseText("Manufacturer_"+manufacturerParamValue+"_"+mainTypeParamValue);
		}
	catch(Exception ex) {
			outputFlag=false;
		}
	System.out.println("Sizes: " + ExternalResponseTextMap.size() +" ...  "+ responseTextMap.size());
	Assert.assertEquals(ExternalResponseTextMap.size(),responseTextMap.size());
	Assert.assertTrue(ExternalResponseTextMap.equals(responseTextMap));
}

@Then("^Validate response for all Manufacturer values for MainTypes$")
public void validate_response_for_all_Manufacturer_values_for_MainTypes() throws Throwable {
	source.parametrizingMainTypesForAllManufacturer();
}


}

