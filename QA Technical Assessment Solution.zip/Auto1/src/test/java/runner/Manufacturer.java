package runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import java.io.*;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import com.cucumber.listener.Reporter;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import java.io.File;
import cucumber.api.testng.AbstractTestNGCucumberTests;


@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/test/java/feature",
		glue= {"gluecode"},
		format= {"pretty",
				"html:target/cucumber/cucumber-pretty",
				"json:target/cucumber.json"},
		tags= {"~@Manufacturer"},
		plugin = { "com.cucumber.listener.ExtentCucumberFormatter:target/ExtentReport.html"},
		  monochrome = true
		
		)

public class Manufacturer {
	@AfterClass
	public static void writeExtentReport() {
		Reporter.loadXMLConfig(new File("src/test/resources/configs/extent-config.xml"));

	
	}

}
